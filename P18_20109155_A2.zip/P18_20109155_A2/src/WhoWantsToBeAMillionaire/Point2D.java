package WhoWantsToBeAMillionaire;

//class to store a 2d point 
//(used in the firework class to keep track of the firework dots)
public class Point2D {

    public int x, y;

    public Point2D(int x, int y) {
        this.x = x;
        this.y = y;
    }

}
