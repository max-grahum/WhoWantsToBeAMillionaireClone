package WhoWantsToBeAMillionaire;

//help class interface
public interface HelpInterface {
     public void setUsed(boolean used);
     public boolean isUsed();
}
 